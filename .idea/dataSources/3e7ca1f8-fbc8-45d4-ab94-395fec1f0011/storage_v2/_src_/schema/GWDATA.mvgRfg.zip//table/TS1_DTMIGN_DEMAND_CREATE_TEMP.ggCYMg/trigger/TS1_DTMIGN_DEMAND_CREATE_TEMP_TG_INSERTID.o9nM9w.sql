create trigger TS1_DTMIGN_DEMAND_CREATE_TEMP_TG_INSERTID
    before insert
    on TS1_DTMIGN_DEMAND_CREATE_TEMP
    for each row
begin
select TS1_DTMIGN_DEMAND_CREATE_TEMP_id.nextval into:new.id from dual;
end;
/

